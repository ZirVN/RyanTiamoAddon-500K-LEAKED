package com.zirvn.addon.config;

import net.minecraft.class_437;

public class ModMenuIntegration {
    public static class_437 createConfigScreen(class_437 parent) {
        return new ModConfigScreen(parent);
    }
}

