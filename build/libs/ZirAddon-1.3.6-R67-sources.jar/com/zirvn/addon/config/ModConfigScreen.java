package com.zirvn.addon.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_6379;
import net.minecraft.class_7923;

public class ModConfigScreen extends class_437 {
    private final class_437 parent;
    private class_342 searchField;
    private BlockItemListWidget list;
    private class_4185 modEnabledBtn;
    private class_4185 autoSneakBtn;
    private class_4185 delayBtn;
    private class_4185 forcedDirBtn;
    private class_4185 limitToSchematicBtn;
    private class_4185 preventInteractionBtn;
    private class_4185 globalToggleBtn;

    private boolean localModEnabled;
    private boolean localAutoSneak;
    private int localPlaceDelayMs;
    private boolean localAllowAllBlockItems;
    private boolean localLimitToSchematic;
    private boolean localPreventInteraction;
    private ModConfig.RotationState localForcedRotationState;
    private final Set<class_1792> localEnabledItems = new HashSet<>();
    private final List<class_1792> allBlockItems = new ArrayList<>();

    public ModConfigScreen(class_437 parent) {
        super(class_2561.method_43470("ZirAddon Config"));
        this.parent = parent;
        ModConfig config = ModConfig.get();
        this.localModEnabled = config.modEnabled;
        this.localAutoSneak = config.autoSneak;
        this.localPlaceDelayMs = config.placeDelayMs;
        this.localAllowAllBlockItems = !config.autoPickFromInventory;
        this.localLimitToSchematic = config.limitToSchematic;
        this.localPreventInteraction = config.preventContainerInteraction;
        this.localForcedRotationState = config.forcedRotationState;

        for (String idStr : config.targetItems) {
            try {
                class_1792 item = class_7923.field_41178.method_63535(class_2960.method_60654(idStr));
                if (item != null && item != class_1802.field_8162) {
                    this.localEnabledItems.add(item);
                }
            } catch (Exception ignored) {}
        }

        for (class_1792 item : class_7923.field_41178) {
            if (item instanceof class_1747) {
                this.allBlockItems.add(item);
            }
        }
        this.allBlockItems.sort(Comparator.comparing(item -> item.method_63680().getString()));
    }

    @Override
    protected void method_25426() {
        int width = Math.min(300, this.field_22789);
        int x = (this.field_22789 - width) / 2;

        this.modEnabledBtn = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("AutoPlace: " + (this.localModEnabled ? "§aON" : "§cOFF")),
            btn -> {
                this.localModEnabled = !this.localModEnabled;
                btn.method_25355(class_2561.method_43470("AutoPlace: " + (this.localModEnabled ? "§aON" : "§cOFF")));
            }
        ).method_46434(x - 20, 10, 95, 20).method_46431());

        this.autoSneakBtn = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Sneak: " + (this.localAutoSneak ? "§aON" : "§cOFF")),
            btn -> {
                this.localAutoSneak = !this.localAutoSneak;
                btn.method_25355(class_2561.method_43470("Sneak: " + (this.localAutoSneak ? "§aON" : "§cOFF")));
            }
        ).method_46434(x + 80, 10, 75, 20).method_46431());

        this.delayBtn = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Delay: §b" + this.localPlaceDelayMs + "ms"),
            btn -> {
                this.localPlaceDelayMs = this.localPlaceDelayMs + 50 > 300 ? 0 : this.localPlaceDelayMs + 50;
                btn.method_25355(class_2561.method_43470("Delay: §b" + this.localPlaceDelayMs + "ms"));
            }
        ).method_46434(x + 160, 10, 85, 20).method_46431());

        this.forcedDirBtn = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Dir: §b" + this.localForcedRotationState.name()),
            btn -> {
                int nextIdx = (this.localForcedRotationState.ordinal() + 1) % ModConfig.RotationState.values().length;
                this.localForcedRotationState = ModConfig.RotationState.values()[nextIdx];
                btn.method_25355(class_2561.method_43470("Dir: §b" + this.localForcedRotationState.name()));
            }
        ).method_46434(x + 330, 10, 90, 20).method_46431());

        this.searchField = new class_342(this.field_22793, x + 20, 36, 140, 20, class_2561.method_43470("Search..."));
        this.searchField.method_1863(this::onSearchChanged);
        this.method_37063(this.searchField);

        this.globalToggleBtn = this.method_37063(class_4185.method_46430(
            getGlobalToggleText(),
            btn -> {
                this.localAllowAllBlockItems = !this.localAllowAllBlockItems;
                btn.method_25355(getGlobalToggleText());
            }
        ).method_46434(x + 175, 36, 105, 20).method_46431());

        this.limitToSchematicBtn = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Lock blocks: " + (this.localLimitToSchematic ? "§aON" : "§cOFF")),
            btn -> {
                this.localLimitToSchematic = !this.localLimitToSchematic;
                btn.method_25355(class_2561.method_43470("Lock blocks: " + (this.localLimitToSchematic ? "§aON" : "§cOFF")));
            }
        ).method_46434(x + 285, 36, 140, 20).method_46431());

        this.preventInteractionBtn = this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Block GUI: " + (this.localPreventInteraction ? "§aON" : "§cOFF")),
            btn -> {
                this.localPreventInteraction = !this.localPreventInteraction;
                btn.method_25355(class_2561.method_43470("Block GUI: " + (this.localPreventInteraction ? "§aON" : "§cOFF")));
            }
        ).method_46434(x + 50, 62, 200, 20).method_46431());

        this.list = new BlockItemListWidget(this.field_22787, width, this.field_22790 - 122, 88, 24);
        this.method_37063(this.list);
        this.onSearchChanged(this.searchField.method_1882());

        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), btn -> saveAndClose()).method_46434(x + 40, this.field_22790 - 28, 100, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), btn -> method_25419()).method_46434(x + 160, this.field_22790 - 28, 100, 20).method_46431());
    }

    private class_2561 getGlobalToggleText() {
        return class_2561.method_43470("All: " + (this.localAllowAllBlockItems ? "§aON" : "§cOFF"));
    }

    private void onSearchChanged(String text) {
        if (this.list != null) {
            this.list.refresh(text);
        }
    }

    private void saveAndClose() {
        ModConfig config = ModConfig.get();
        config.modEnabled = this.localModEnabled;
        config.autoSneak = this.localAutoSneak;
        config.placeDelayMs = this.localPlaceDelayMs;
        config.limitToSchematic = this.localLimitToSchematic;
        config.preventContainerInteraction = this.localPreventInteraction;
        config.forcedRotationState = this.localForcedRotationState;

        List<String> list = new ArrayList<>();
        for (class_1792 item : this.localEnabledItems) {
            class_2960 id = class_7923.field_41178.method_10221(item);
            if (id != null) {
                list.add(id.toString());
            }
        }
        config.targetItems = list;
        ModConfig.save();
        method_25419();
    }

    @Override
    public void method_25419() {
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 4, 0xFFFFFF);
    }

    class BlockItemListWidget extends class_4265<BlockItemListWidget.Entry> {
        public BlockItemListWidget(class_310 client, int width, int height, int top, int itemHeight) {
            super(client, width, height, top, itemHeight);
        }

        public void refresh(String filter) {
            this.method_25339();
            String query = filter.toLowerCase(Locale.ROOT);
            for (class_1792 item : ModConfigScreen.this.allBlockItems) {
                String name = item.method_63680().getString();
                String idStr = class_7923.field_41178.method_10221(item).toString();
                if (name.toLowerCase(Locale.ROOT).contains(query) || idStr.contains(query)) {
                    this.method_25321(new Entry(item));
                }
            }
        }

        class Entry extends class_4265.class_4266<Entry> {
            private final class_1792 item;
            private final class_4185 toggleButton;

            public Entry(class_1792 item) {
                this.item = item;
                this.toggleButton = class_4185.method_46430(getToggleText(), btn -> {
                    if (ModConfigScreen.this.localEnabledItems.contains(item)) {
                        ModConfigScreen.this.localEnabledItems.remove(item);
                    } else {
                        ModConfigScreen.this.localEnabledItems.add(item);
                    }
                    btn.method_25355(getToggleText());
                }).method_46434(0, 0, 50, 20).method_46431();
            }

            private class_2561 getToggleText() {
                return class_2561.method_43470(ModConfigScreen.this.localEnabledItems.contains(this.item) ? "§aON" : "§cOFF");
            }

            @Override
            public void method_25343(class_332 context, int mouseX, int mouseY, boolean hovered, float tickDelta) {
                context.method_51427(new class_1799(this.item), 4, 2);
                String name = this.item.method_63680().getString();
                if (name.length() > 22) {
                    name = name.substring(0, 20) + "...";
                }
                context.method_25303(ModConfigScreen.this.field_22793, name, 26, 6, 0xFFFFFF);
                this.toggleButton.method_25394(context, mouseX, mouseY, tickDelta);
            }



            @Override
            public List<? extends class_364> method_25396() {
                return Collections.singletonList(this.toggleButton);
            }

            @Override
            public List<? extends class_6379> method_37025() {
                return Collections.singletonList(this.toggleButton);
            }
        }
    }
}

