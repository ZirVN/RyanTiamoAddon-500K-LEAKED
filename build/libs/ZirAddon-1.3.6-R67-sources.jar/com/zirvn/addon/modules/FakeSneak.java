package com.zirvn.addon.modules;

import com.zirvn.addon.ZirAddon;
import java.util.List;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public class FakeSneak extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<List<class_2248>> blocks;
    private static FakeSneak instance;

    public FakeSneak() {
        super(ZirAddon.CATEGORY, "fake-sneak", "Auto sneaks when interacting with specified blocks so you can place blocks on them without opening their GUI");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.blocks = this.sgGeneral.add(new BlockListSetting.Builder()
            .name("blocks")
            .description("Blocks to auto-sneak when interacting with")
            .defaultValue(List.of(
                class_2246.field_10034, class_2246.field_10380, class_2246.field_10443, class_2246.field_10535, class_2246.field_10105, class_2246.field_10414,
                class_2246.field_9980, class_2246.field_10181, class_2246.field_16333, class_2246.field_16334, class_2246.field_16328, class_2246.field_10312,
                class_2246.field_10200, class_2246.field_10228, class_2246.field_10333, class_2246.field_10327, class_2246.field_10485, class_2246.field_10083,
                class_2246.field_16336, class_2246.field_16337, class_2246.field_16335, class_2246.field_16329, class_2246.field_10603,
                class_2246.field_10199, class_2246.field_10407, class_2246.field_10063, class_2246.field_10203,
                class_2246.field_10600, class_2246.field_10275, class_2246.field_10051, class_2246.field_10140,
                class_2246.field_10320, class_2246.field_10532, class_2246.field_10268, class_2246.field_10605,
                class_2246.field_10373, class_2246.field_10055, class_2246.field_10068, class_2246.field_10371
            ))
            .build());
        instance = this;
    }

    public static boolean shouldSneak(class_2248 block) {
        return instance != null && instance.isActive() && instance.blocks.get().contains(block);
    }

}

