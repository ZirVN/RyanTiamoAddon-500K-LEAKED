package com.zirvn.addon.modules;

import com.zirvn.addon.ZirAddon;
import com.zirvn.addon.config.ModConfig;
import com.zirvn.addon.mixins.PlayerInventoryAccessor;
import com.zirvn.addon.util.RotationSpoofer;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10185;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2286;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2462;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2747;
import net.minecraft.class_2851;
import net.minecraft.class_3965;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class AutoPlace extends Module {
    private final SettingGroup sgGeneral;
    private final Setting<Integer> placeDelayMs;
    private final Setting<Boolean> autoPick;
    private final Setting<Boolean> limitToSchematic;
    private final Setting<Boolean> preventGui;
    private final Setting<Boolean> adjustRedstone;
    private final Setting<Boolean> pauseMovement;
    private final Setting<Boolean> lockLayer;
    private final Setting<Boolean> lockToSchematic;

    private final SettingGroup sgRotationFilter;
    private final Setting<Boolean> rotationFilterEnabled;
    private final Setting<List<class_1792>> rotationItems;

    private final SettingGroup sgAirPlace;
    private final Setting<Boolean> airPlace;
    private final Setting<List<class_1792>> supportBlocks;

    private final SettingGroup sgSafety;
    private final Setting<Boolean> safetyMode;
    private final Setting<Integer> delayVariance;

    private final Random random;

    public AutoPlace() {
        super(ZirAddon.CATEGORY, "auto-place", "Auto places blocks from Litematica schematic with correct rotation, item swap, and air place support");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.placeDelayMs = this.sgGeneral.add(new IntSetting.Builder().name("place-delay-ms").description("Delay between placements in ms").defaultValue(0).min(0).max(500).sliderRange(0, 300).build());

        this.autoPick = this.sgGeneral.add(new BoolSetting.Builder().name("auto-pick").description("Auto pick items from inventory").defaultValue(true).build());
        this.limitToSchematic = this.sgGeneral.add(new BoolSetting.Builder().name("limit-to-schematic").description("Only place blocks matching the schematic").defaultValue(true).build());
        this.preventGui = this.sgGeneral.add(new BoolSetting.Builder().name("prevent-gui").description("Auto sneak to prevent opening containers").defaultValue(true).build());
        this.adjustRedstone = this.sgGeneral.add(new BoolSetting.Builder().name("adjust-redstone").description("Auto adjust repeater delays and comparator modes").defaultValue(true).build());
        this.pauseMovement = this.sgGeneral.add(new BoolSetting.Builder().name("pause-movement").description("Pause movement during place delay").defaultValue(true).build());
        this.lockLayer = this.sgGeneral.add(new BoolSetting.Builder().name("lock-layer").description("Only place blocks within the current Litematica layer range").defaultValue(false).build());
        this.lockToSchematic = this.sgGeneral.add(new BoolSetting.Builder().name("lock-to-schematic").description("Block placement at positions where schematic has no block (air).").defaultValue(false).build());

        this.sgRotationFilter = this.settings.createGroup("Rotation Filter");
        this.rotationFilterEnabled = this.sgRotationFilter.add(new BoolSetting.Builder().name("filter-enabled").description("Only apply rotation to selected blocks").defaultValue(false).build());
        this.rotationItems = this.sgRotationFilter.add(new ItemListSetting.Builder().name("rotation-items").description("Blocks to apply rotation spoofing to").defaultValue(List.of()).build());

        this.sgAirPlace = this.settings.createGroup("Air Place");
        this.airPlace = this.sgAirPlace.add(new BoolSetting.Builder().name("air-place").description("Auto place support blocks when target has no solid block to place against").defaultValue(false).build());
        this.supportBlocks = this.sgAirPlace.add(new ItemListSetting.Builder().name("support-blocks").description("Blocks to use as temporary support for air placement").defaultValue(List.of()).build());

        this.sgSafety = this.settings.createGroup("Safety");
        this.safetyMode = this.sgSafety.add(new BoolSetting.Builder().name("safety-mode").description("Enable anti-suspicious features (random delays, human-like rotation)").defaultValue(true).build());
        this.delayVariance = this.sgSafety.add(new IntSetting.Builder().name("delay-variance").description("Random delay variance in ms to avoid pattern detection").defaultValue(30).min(0).max(200).build());

        this.random = new Random();
    }

    @Override
    public void onActivate() {
        ModConfig.load();
        ModConfig config = ModConfig.get();
        config.modEnabled = true;
        this.syncConfig();
        ModConfig.save();
    }

    @Override
    public void onDeactivate() {
        ModConfig config = ModConfig.get();
        config.modEnabled = false;
        ModConfig.save();
    }

    private void syncConfig() {
        ModConfig config = ModConfig.get();
        config.placeDelayMs = this.placeDelayMs.get();
        config.autoPickFromInventory = this.autoPick.get();
        config.limitToSchematic = this.limitToSchematic.get();
        config.preventContainerInteraction = this.preventGui.get();
        config.pauseMovementDuringDelay = this.pauseMovement.get();
    }

    public boolean isAutoPick() { return this.autoPick.get(); }
    public boolean isLimitToSchematic() { return this.limitToSchematic.get(); }
    public boolean isPreventGui() { return this.preventGui.get(); }
    public boolean isAdjustRedstone() { return this.adjustRedstone.get(); }
    public boolean isPauseMovement() { return this.pauseMovement.get(); }
    public boolean isLockLayer() { return this.lockLayer.get(); }
    public boolean isLockToSchematic() { return this.lockToSchematic.get(); }
    public int getPlaceDelayMs() { return this.placeDelayMs.get(); }

    public boolean shouldRotate(class_1792 item) {
        return !this.rotationFilterEnabled.get() || this.rotationItems.get().contains(item);
    }

    public boolean isSafetyMode() {
        return this.safetyMode.get();
    }

    public int getDelayVariance() {
        return this.delayVariance.get();
    }

    public int getRandomDelayOffset() {
        int v = this.delayVariance.get();
        return v > 0 ? this.random.nextInt(v + 1) - v / 2 : 0;
    }

    public boolean isAirPlaceEnabled() {
        return this.airPlace.get();
    }

    public List<class_1792> getSupportBlocks() {
        return this.supportBlocks.get();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (this.mc.field_1724 == null || this.mc.field_1687 == null) return;

        this.syncConfig();

        // 1. Process pending block adjustments (Repeater delay / Comparator mode)
        if (this.isAdjustRedstone() && !RotationSpoofer.pendingAdjustments.isEmpty()) {
            long now = System.currentTimeMillis();
            Iterator<RotationSpoofer.PendingAdjustment> iterator = RotationSpoofer.pendingAdjustments.iterator();
            boolean clickSentThisTick = false;
            while (iterator.hasNext()) {
                RotationSpoofer.PendingAdjustment adj = iterator.next();
                if (now - adj.timeCreated > 2000) {
                    iterator.remove();
                    continue;
                }
                
                class_1937 schematicWorld = SchematicWorldHandler.getSchematicWorld();
                if (schematicWorld == null) {
                    iterator.remove();
                    continue;
                }

                if (adj.clicksLeft == -1 && now - adj.timeCreated > 50) {
                    class_2680 worldState = this.mc.field_1687.method_8320(adj.pos);
                    class_2680 schemState = schematicWorld.method_8320(adj.pos);

                    if (worldState.method_26204() instanceof class_2462 && schemState.method_26204() instanceof class_2462) {
                        int worldDelay = worldState.method_11654(class_2741.field_12494);
                        int schemDelay = schemState.method_11654(class_2741.field_12494);
                        adj.clicksLeft = (schemDelay - worldDelay + 4) % 4;
                    } else if (worldState.method_26204() instanceof class_2286 && schemState.method_26204() instanceof class_2286) {
                        class_2747 worldMode = worldState.method_11654(class_2741.field_12534);
                        class_2747 schemMode = schemState.method_11654(class_2741.field_12534);
                        adj.clicksLeft = (worldMode != schemMode) ? 1 : 0;
                    } else if (!worldState.method_26215()) {
                        iterator.remove();
                        continue;
                    }
                }

                if (adj.clicksLeft > 0) {
                    if (!clickSentThisTick && this.mc.field_1761 != null) {
                        class_3965 adjustHitResult = new class_3965(
                            new class_243(adj.pos.method_10263() + 0.5, adj.pos.method_10264() + 0.5, adj.pos.method_10260() + 0.5),
                            class_2350.field_11036,
                            adj.pos,
                            false
                        );
                        this.mc.field_1761.method_2896(this.mc.field_1724, adj.hand, adjustHitResult);
                        adj.clicksLeft--;
                        clickSentThisTick = true;
                    }
                    if (adj.clicksLeft == 0) {
                        iterator.remove();
                    }
                } else if (adj.clicksLeft == 0) {
                    iterator.remove();
                }
            }
        }

        // 2. Execute queued placement with spoofed rotation
        if (RotationSpoofer.isQueued) {
            RotationSpoofer.pendingTicks++;
            if (RotationSpoofer.spoofSent || RotationSpoofer.pendingTicks >= 2) {
                RotationSpoofer.spoofSent = false;
                RotationSpoofer.pendingTicks = 0;

                float oldYaw = this.mc.field_1724.method_36454();
                float oldPitch = this.mc.field_1724.method_36455();
                this.mc.field_1724.method_36456(RotationSpoofer.targetYaw);
                this.mc.field_1724.method_36457(RotationSpoofer.targetPitch);
                
                RotationSpoofer.isPlacingLater = true;
                if (RotationSpoofer.savedHand != null && RotationSpoofer.savedHitResult != null && this.mc.field_1761 != null) {
                    boolean shouldSneak = this.isPreventGui() && !this.mc.field_1724.method_5715();
                    class_10185 normalInput = null;
                    
                    if (shouldSneak && this.mc.method_1562() != null) {
                        normalInput = this.mc.field_1724.field_3913.field_54155;
                        class_10185 sneakInput = new class_10185(
                            normalInput.comp_3159(),
                            normalInput.comp_3160(),
                            normalInput.comp_3161(),
                            normalInput.comp_3162(),
                            normalInput.comp_3163(),
                            true,
                            normalInput.comp_3165()
                        );
                        this.mc.method_1562().method_52787(new class_2851(sneakInput));
                    }
                    
                    this.mc.field_1761.method_2896(this.mc.field_1724, RotationSpoofer.savedHand, RotationSpoofer.savedHitResult);
                    RotationSpoofer.lastPlaceTime = System.currentTimeMillis();
                    
                    if (shouldSneak && normalInput != null && this.mc.method_1562() != null) {
                        this.mc.method_1562().method_52787(new class_2851(normalInput));
                    }
                    
                    try {
                        if (RotationSpoofer.savedPlacedPos != null && this.isAdjustRedstone()) {
                            RotationSpoofer.pendingAdjustments.add(new RotationSpoofer.PendingAdjustment(
                                    RotationSpoofer.savedPlacedPos,
                                    RotationSpoofer.savedHand,
                                    RotationSpoofer.savedHitResult
                            ));
                        }
                    } catch (Exception ignored) {}
                }
                
                RotationSpoofer.isPlacingLater = false;
                this.mc.field_1724.method_36456(oldYaw);
                this.mc.field_1724.method_36457(oldPitch);
                
                RotationSpoofer.isQueued = false;
                RotationSpoofer.isSpoofing = false;
            }
        }
    }
}
