package com.zirvn.addon.modules;

import com.zirvn.addon.ZirAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_3965;
import java.util.List;

public class AutoDirection extends Module {
    private final SettingGroup sgGeneral;
    public final Setting<Direction> direction;
    public final Setting<List<class_1792>> blocks;

    private static AutoDirection instance;
    private static boolean activeState = false;
    private static class_1268 pendingHand = null;
    private static class_3965 pendingHitResult = null;
    private static int stepState = 0;
    public static volatile int ticksToOverride = 0;
    public static float overrideYaw = 0.0F;
    public static float overridePitch = 0.0F;

    public AutoDirection() {
        super(ZirAddon.CATEGORY, "auto-direction", "Auto sets block direction for selected blocks.");
        this.sgGeneral = this.settings.getDefaultGroup();
        this.direction = this.sgGeneral.add(new EnumSetting.Builder<Direction>()
            .name("direction")
            .description("Block facing direction.")
            .defaultValue(Direction.NORTH)
            .build());
        this.blocks = this.sgGeneral.add(new ItemListSetting.Builder()
            .name("blocks")
            .description("Blocks to apply direction to.")
            .defaultValue(class_1802.field_8249, class_1802.field_8105, class_1802.field_8357, class_1802.field_8878, class_1802.field_8239, class_1802.field_8537)
            .build());
        instance = this;
    }

    public static boolean applyDirection(class_1792 item, class_1268 hand, class_3965 hitResult) {
        if (instance != null && instance.isActive()) {
            if (!(item instanceof class_1747)) {
                return false;
            } else if (!instance.blocks.get().contains(item)) {
                return false;
            } else if (activeState) {
                return false;
            } else {
                activeState = true;
                pendingHand = hand;
                pendingHitResult = hitResult;
                stepState = 0;
                return true;
            }
        } else {
            return false;
        }
    }


    static float getYawForDirection(Direction dir) {
        return switch (dir) {
            case NORTH -> 180.0F;
            case SOUTH -> 0.0F;
            case EAST -> -90.0F;
            case WEST -> 90.0F;
            default -> Float.NaN;
        };
    }

    static float getPitchForDirection(Direction dir) {
        return switch (dir) {
            case UP -> 90.0F;
            case DOWN -> -90.0F;
            default -> 0.0F;
        };
    }

    @Override
    public void onActivate() {
        activeState = false;
    }

    @Override
    public void onDeactivate() {
        activeState = false;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (activeState && this.mc.field_1724 != null) {
            if (stepState == 0) {
                Direction dir = this.direction.get();
                overrideYaw = getYawForDirection(dir);
                overridePitch = getPitchForDirection(dir);
                ticksToOverride = 2;
                stepState = 1;
            } else if (stepState == 1) {
                if (pendingHand != null && pendingHitResult != null && this.mc.field_1761 != null) {
                    this.mc.field_1761.method_2896(this.mc.field_1724, pendingHand, pendingHitResult);
                }
                activeState = false;
                stepState = 0;
            }
        }
    }

    public enum Direction {
        UP,
        DOWN,
        NORTH,
        SOUTH,
        EAST,
        WEST
    }
}
