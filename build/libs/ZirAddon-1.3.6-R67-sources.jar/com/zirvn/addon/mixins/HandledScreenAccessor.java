package com.zirvn.addon.mixins;

import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_465.class)
public interface HandledScreenAccessor {
    @Invoker("onSlotChangedState")
    void invokeOnSlotChangedState(int slotId, int containerId, boolean newState);
}

