package com.zirvn.addon.mixins;

import com.zirvn.addon.modules.AutoDirection;
import com.zirvn.addon.modules.AutoPlace;
import com.zirvn.addon.util.RotationCalculator;
import com.zirvn.addon.util.RotationSpoofer;
import fi.dy.masa.litematica.data.DataManager;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import fi.dy.masa.malilib.util.LayerRange;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.block.*;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1713;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2199;
import net.minecraft.class_2237;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2272;
import net.minecraft.class_2286;
import net.minecraft.class_2304;
import net.minecraft.class_2323;
import net.minecraft.class_2331;
import net.minecraft.class_2338;
import net.minecraft.class_2349;
import net.minecraft.class_2362;
import net.minecraft.class_2387;
import net.minecraft.class_2401;
import net.minecraft.class_2406;
import net.minecraft.class_2428;
import net.minecraft.class_2462;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2851;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_3709;
import net.minecraft.class_3711;
import net.minecraft.class_3713;
import net.minecraft.class_3715;
import net.minecraft.class_3717;
import net.minecraft.class_3718;
import net.minecraft.class_3962;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import net.minecraft.class_7714;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {

    private boolean spoofedSneak = false;

    private boolean shouldSneakPlaceAgainst(class_746 player, class_3965 hitResult) {
        class_2680 state = player.method_73183().method_8320(hitResult.method_17777());
        class_2248 block = state.method_26204();
        return block instanceof class_2237
            || block instanceof class_2304
            || block instanceof class_2199
            || block instanceof class_2406
            || block instanceof class_3711
            || block instanceof class_3713
            || block instanceof class_3718
            || block instanceof class_3717
            || block instanceof class_3715
            || block instanceof class_2331
            || block instanceof class_2401
            || block instanceof class_2269
            || block instanceof class_2349
            || block instanceof class_2323
            || block instanceof class_2533
            || block instanceof class_2428
            || block instanceof class_2387
            || block instanceof class_2462
            || block instanceof class_2286
            || block instanceof class_2244
            || block instanceof class_3709
            || block instanceof class_3962
            || block instanceof class_7714
            || block instanceof class_2362
            || block instanceof class_2272;
    }

    private static long lastInvSwapTime = 0;

    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void onInteractBlockHead(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        if (player == null) return;

        AutoPlace autoPlace = Modules.get().get(AutoPlace.class);
        AutoDirection autoDir = Modules.get().get(AutoDirection.class);

        boolean isAutoPlaceActive = autoPlace != null && autoPlace.isActive();
        boolean isAutoDirActive = autoDir != null && autoDir.isActive();

        if (!isAutoPlaceActive && !isAutoDirActive) return;

        // Block manual player interaction with Repeater or Comparator to prevent accidental tick adjustment
        if (isAutoPlaceActive && autoPlace.isAdjustRedstone() && !RotationSpoofer.isPlacingLater) {
            class_2248 clickedBlock = class_310.method_1551().field_1687.method_8320(hitResult.method_17777()).method_26204();
            if (clickedBlock instanceof class_2462 || clickedBlock instanceof class_2286) {
                cir.setReturnValue(class_1269.field_5814);
                return;
            }
        }

        // Prevent GUI / Auto Sneak
        boolean preventGui = isAutoPlaceActive && autoPlace.isPreventGui();
        if (preventGui && !player.method_5715() && shouldSneakPlaceAgainst(player, hitResult)) {
            this.spoofedSneak = true;
            player.field_3944.method_52787(new class_2851(new class_10185(false, false, false, false, false, true, false)));
        }

        // If this is the delayed placement event triggered from client tick, allow vanilla interactBlock to execute
        if (RotationSpoofer.isPlacingLater) {
            return;
        }

        // Handle AutoDirection
        if (AutoDirection.applyDirection(player.method_5998(hand).method_7909(), hand, hitResult)) {
            cir.setReturnValue(class_1269.field_5814);
            return;
        }

        if (!isAutoPlaceActive) {
            return;
        }

        // If a spoofed placement is already queued in this tick, fail this interaction so Litematica retries later
        if (RotationSpoofer.isQueued) {
            cir.setReturnValue(class_1269.field_5814);
            return;
        }

        // Enforce Placement Delay
        if (System.currentTimeMillis() - RotationSpoofer.lastPlaceTime < autoPlace.getPlaceDelayMs()) {
            cir.setReturnValue(class_1269.field_5814);
            return;
        }

        class_1937 schematicWorld = SchematicWorldHandler.getSchematicWorld();
        if (schematicWorld == null) return;

        class_1799 currentStack = player.method_5998(hand);
        
        class_2338 targetPos;
        if (currentStack.method_7909() instanceof class_1755 || currentStack.method_7909() == class_1802.field_27876) {
            class_2680 clickedState = class_310.method_1551().field_1687.method_8320(hitResult.method_17777());
            if (clickedState.method_45474()) {
                targetPos = hitResult.method_17777();
            } else {
                targetPos = hitResult.method_17777().method_10093(hitResult.method_17780());
            }
        } else {
            class_1750 placementCtx = new class_1750(player, hand, currentStack, hitResult);
            targetPos = placementCtx.method_8037();
        }

        // Lock Layer setting
        if (autoPlace.isLockLayer()) {
            LayerRange range = DataManager.getRenderLayerRange();
            if (range != null && !range.isPositionWithinRange(targetPos)) {
                cir.setReturnValue(class_1269.field_5814);
                return;
            }
        }

        class_2680 stateSchematic = schematicWorld.method_8320(targetPos);

        // Limit / Lock to Schematic setting
        if (autoPlace.isLimitToSchematic() || autoPlace.isLockToSchematic()) {
            if (stateSchematic == null || stateSchematic.method_26215()) {
                if (currentStack.method_7909() instanceof class_1747 || currentStack.method_7909() instanceof class_1755) {
                    cir.setReturnValue(class_1269.field_5814);
                    return;
                }
                return;
            }
        }

        if (stateSchematic == null || stateSchematic.method_26215()) {
            return;
        }

        class_1792 requiredItem = stateSchematic.method_26204().method_8389();
        if (stateSchematic.method_26204() == class_2246.field_10382) {
            requiredItem = class_1802.field_8705;
        } else if (stateSchematic.method_26204() == class_2246.field_10164) {
            requiredItem = class_1802.field_8187;
        } else if (stateSchematic.method_26204() == class_2246.field_27879) {
            requiredItem = class_1802.field_27876;
        }

        // Auto Pick setting (instant swap, zero delay)
        if (autoPlace.isAutoPick() && currentStack.method_7909() != requiredItem && hand == class_1268.field_5808) {
            int foundSlot = -1;
            for (int i = 0; i < 36; i++) {
                if (player.method_31548().method_5438(i).method_7909() == requiredItem) {
                    foundSlot = i;
                    break;
                }
            }

            if (foundSlot != -1) {
                if (foundSlot < 9) {
                    ((PlayerInventoryAccessor) player.method_31548()).setSelectedSlot(foundSlot);
                    class_310.method_1551().method_1562().method_52787(
                            new class_2868(foundSlot)
                    );
                } else {
                    int activeHotbarSlot = ((PlayerInventoryAccessor) player.method_31548()).getSelectedSlot();
                    class_310.method_1551().field_1761.method_2906(
                            player.field_7498.field_7763,
                            foundSlot,
                            activeHotbarSlot,
                            class_1713.field_7791,
                            player
                    );
                    cir.setReturnValue(class_1269.field_5814);
                    return;
                }
            }
        }



        // Re-fetch stack after potential swap
        class_1799 stack = player.method_5998(hand);
        if (stack.method_7960()) return;
        if (!(stack.method_7909() instanceof class_1747) && !(stack.method_7909() instanceof class_1755)) return;
        if (stack.method_7909() != requiredItem) {
            cir.setReturnValue(class_1269.field_5814);
            return;
        }

        if (!autoPlace.shouldRotate(stack.method_7909())) {
            queueAdjustmentIfRequired(targetPos, hand, hitResult, stateSchematic);
            return;
        }

        RotationCalculator.TargetRotation rot = RotationCalculator.getRequiredRotation(stateSchematic, player);

        if (rot != null) {
            if (RotationCalculator.isAlreadyCorrectRotation(player, rot)) {
                queueAdjustmentIfRequired(targetPos, hand, hitResult, stateSchematic);
                return;
            }

            float rawSpoofedYaw = rot.yaw != null ? rot.yaw : player.method_36454();
            float rawSpoofedPitch = rot.pitch != null ? rot.pitch : player.method_36455();

            float spoofedYaw = RotationCalculator.alignYawToSensitivity(rawSpoofedYaw, player.method_36454(), class_310.method_1551());
            float spoofedPitch = RotationCalculator.alignPitchToSensitivity(rawSpoofedPitch, player.method_36455(), class_310.method_1551());

            if (RotationSpoofer.isQueued) {
                cir.setReturnValue(class_1269.field_5814);
                return;
            }

            RotationSpoofer.isQueued = true;
            RotationSpoofer.targetYaw = spoofedYaw;
            RotationSpoofer.targetPitch = spoofedPitch;
            RotationSpoofer.savedHand = hand;
            RotationSpoofer.savedHitResult = hitResult;
            RotationSpoofer.savedPlacedPos = targetPos;



            RotationSpoofer.currentSpoofedYaw = spoofedYaw;
            RotationSpoofer.currentSpoofedPitch = spoofedPitch;
            RotationSpoofer.isSpoofing = true;

            cir.setReturnValue(class_1269.field_5814);
        } else {
            queueAdjustmentIfRequired(targetPos, hand, hitResult, stateSchematic);
        }
    }

    @Inject(method = "interactBlock", at = @At("RETURN"))
    private void onInteractBlockReturn(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
        if (this.spoofedSneak) {
            this.spoofedSneak = false;
            if (player != null && !player.method_5715()) {
                player.field_3944.method_52787(new class_2851(new class_10185(false, false, false, false, false, false, false)));
            }
        }
    }

    private void queueAdjustmentIfRequired(class_2338 targetPos, class_1268 hand, class_3965 hitResult, class_2680 stateSchematic) {
        AutoPlace autoPlace = Modules.get().get(AutoPlace.class);
        if (autoPlace != null && autoPlace.isActive() && autoPlace.isAdjustRedstone()) {
            if (stateSchematic != null && (stateSchematic.method_26204() instanceof class_2462 || stateSchematic.method_26204() instanceof class_2286)) {
                RotationSpoofer.pendingAdjustments.add(new RotationSpoofer.PendingAdjustment(
                        targetPos,
                        hand,
                        hitResult
                ));
            }
        }
    }
}
