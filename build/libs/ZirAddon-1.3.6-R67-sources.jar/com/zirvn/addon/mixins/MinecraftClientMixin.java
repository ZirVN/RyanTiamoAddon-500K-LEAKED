package com.zirvn.addon.mixins;

import com.zirvn.addon.config.ModConfig;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftClientMixin {

    @Shadow
    public class_239 crosshairTarget;

    @Inject(method = "doItemUse", at = @At("HEAD"))
    private void onDoItemUseHead(CallbackInfo ci) {
        class_310 client = (class_310) (Object) this;
        if (ModConfig.get().modEnabled) {
            if (client.field_1724 != null && client.field_1687 != null) {
                if (this.crosshairTarget == null || this.crosshairTarget.method_17783() == class_239.class_240.field_1333) {
                    class_2338 schematicPos = rayTraceSchematic(client);
                    if (schematicPos != null) {
                        class_243 hitVec = new class_243((double) schematicPos.method_10263() + 0.5D, (double) schematicPos.method_10264() + 0.5D, (double) schematicPos.method_10260() + 0.5D);
                        this.crosshairTarget = new class_3965(hitVec, class_2350.field_11036, schematicPos, false);
                    }
                }
            }
        }
    }

    @Unique
    private static class_2338 rayTraceSchematic(class_310 client) {
        if (client.field_1724 == null) {
            return null;
        }
        class_243 cameraPos = client.field_1724.method_5836(1.0F);
        class_243 rotation = client.field_1724.method_5828(1.0F);
        double reach = 5.0D;

        for (double d = 0.0D; d <= reach; d += 0.1) {
            class_243 currentPos = cameraPos.method_1019(rotation.method_1021(d));
            class_2338 pos = class_2338.method_49637(currentPos.field_1352, currentPos.field_1351, currentPos.field_1350);
            
            class_2680 schematicState = null;
            try {
                if (SchematicWorldHandler.getSchematicWorld() != null) {
                    schematicState = SchematicWorldHandler.getSchematicWorld().method_8320(pos);
                }
            } catch (Throwable ignored) {}

            if (schematicState != null && !schematicState.method_26215()) {
                if (client.field_1687 != null && client.field_1687.method_8320(pos).method_26215()) {
                    return pos;
                }
            }
        }

        return null;
    }
}
