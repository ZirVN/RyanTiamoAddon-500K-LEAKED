package com.zirvn.addon.mixins;

import net.minecraft.class_1661;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1661.class)
public interface PlayerInventoryAccessor {
    @Accessor("selectedSlot")
    void setSelectedSlot(int slot);

    @Accessor("selectedSlot")
    int getSelectedSlot();
}

