package com.zirvn.addon.mixins;

import com.zirvn.addon.config.ModConfig;
import com.zirvn.addon.modules.AutoDirection;
import com.zirvn.addon.util.RotationSpoofer;
import net.minecraft.class_10185;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {
    private static boolean didAutoDirSpoof = false;
    private static float savedYaw = 0.0F;
    private static float savedPitch = 0.0F;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void onSendMovementPacketsHead(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;

        if (AutoDirection.ticksToOverride > 0) {
            didAutoDirSpoof = true;
            --AutoDirection.ticksToOverride;
            savedYaw = player.method_36454();
            savedPitch = player.method_36455();
            if (!Float.isNaN(AutoDirection.overrideYaw)) {
                player.method_36456(AutoDirection.overrideYaw);
            }
            if (!Float.isNaN(AutoDirection.overridePitch)) {
                player.method_36457(AutoDirection.overridePitch);
            }
        } else if (RotationSpoofer.isSpoofing) {
            RotationSpoofer.originalYaw = player.method_36454();
            RotationSpoofer.originalPitch = player.method_36455();

            player.method_36456(RotationSpoofer.currentSpoofedYaw);
            player.method_36457(RotationSpoofer.currentSpoofedPitch);
        }
    }

    @Inject(method = "sendMovementPackets", at = @At("TAIL"))
    private void onSendMovementPacketsTail(CallbackInfo ci) {
        class_746 player = (class_746) (Object) this;

        if (didAutoDirSpoof) {
            didAutoDirSpoof = false;
            player.method_36456(savedYaw);
            player.method_36457(savedPitch);
        } else if (RotationSpoofer.isSpoofing) {
            player.method_36456(RotationSpoofer.originalYaw);
            player.method_36457(RotationSpoofer.originalPitch);
            RotationSpoofer.spoofSent = true;
        }
    }

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void onTickMovementHead(CallbackInfo ci) {
        if (ModConfig.get().modEnabled && ModConfig.get().pauseMovementDuringDelay) {
            long elapsed = System.currentTimeMillis() - RotationSpoofer.lastPlaceTime;
            if (elapsed < ModConfig.get().placeDelayMs) {
                class_746 player = (class_746) (Object) this;
                if (player.field_3913 != null && player.field_3913.field_54155 != null) {
                    class_10185 oldInput = player.field_3913.field_54155;
                    player.field_3913.field_54155 = new class_10185(
                        false, false, false, false,
                        oldInput.comp_3163(),
                        oldInput.comp_3164(),
                        oldInput.comp_3165()
                    );
                }
            }
        }
    }
}
