package com.zirvn.addon.mixins;

import com.zirvn.addon.modules.CrafterSetup;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_8881;
import net.minecraft.class_8898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_8898.class)
public class CrafterScreenMixin {
    @Inject(
        method = "init",
        at = @At("TAIL")
    )
    private void onInit(CallbackInfo ci) {
        CrafterSetup setup = Modules.get().get(CrafterSetup.class);
        if (setup != null && setup.isActive()) {
            class_8881 handler = ((class_8898) (Object) this).method_17577();
            HandledScreenAccessor accessor = (HandledScreenAccessor) this;

            for (int i = 0; i < 9; ++i) {
                boolean disabled = setup.isSlotDisabled(i);
                handler.method_54458(i, !disabled);
                accessor.invokeOnSlotChangedState(i, handler.field_7763, !disabled);
            }
        }
    }
}

