package com.zirvn.addon.mixins;

import com.zirvn.addon.modules.AutoSell;
import net.minecraft.class_2561;
import net.minecraft.class_338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_338.class)
public class ChatHudMixin {
    @Inject(
        method = "addMessage(Lnet/minecraft/text/Text;)V",
        at = @At("HEAD")
    )
    private void onAddMessage(class_2561 message, CallbackInfo ci) {
        if (message != null) {
            try {
                AutoSell.onChatMessage(message.getString());
            } catch (Exception ignored) {}
        }
    }
}

