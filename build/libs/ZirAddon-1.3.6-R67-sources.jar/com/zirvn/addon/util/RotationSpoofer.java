package com.zirvn.addon.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_3965;

public class RotationSpoofer {
    public static boolean shouldPlaceBlockLater = false;
    public static boolean isPlacingLater = false;

    public static float originalYaw = 0.0f;
    public static float originalPitch = 0.0f;
    public static float spoofedYaw = 0.0f;
    public static float spoofedPitch = 0.0f;

    public static class_1268 savedHand;
    public static class_3965 savedHitResult;
    public static class_2338 savedPlacedPos;
    
    public static long lastPlaceTime = 0;

    // Smooth Rotation State
    public static boolean isQueued = false;
    public static boolean isSpoofing = false;
    public static float targetYaw = 0.0f;
    public static float targetPitch = 0.0f;
    public static float startYaw = 0.0f;
    public static float startPitch = 0.0f;
    public static float currentSpoofedYaw = 0.0f;
    public static float currentSpoofedPitch = 0.0f;
    public static int currentStep = 0;
    public static int totalSteps = 2;
    
    // Safety delay flags
    public static boolean spoofSent = false;
    public static int pendingTicks = 0;

    public static class PendingAdjustment {
        public final class_2338 pos;
        public final class_1268 hand;
        public final class_3965 hitResult;
        public final long timeCreated;
        public int clicksLeft = -1;

        public PendingAdjustment(class_2338 pos, class_1268 hand, class_3965 hitResult) {
            this.pos = pos;
            this.hand = hand;
            this.hitResult = hitResult;
            this.timeCreated = System.currentTimeMillis();
        }
    }

    public static final List<PendingAdjustment> pendingAdjustments = new ArrayList<>();
}
