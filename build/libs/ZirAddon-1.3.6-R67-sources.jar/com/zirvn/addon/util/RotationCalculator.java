package com.zirvn.addon.util;

import net.minecraft.block.*;
import net.minecraft.class_2199;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2350;
import net.minecraft.class_2377;
import net.minecraft.class_2426;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5000;
import net.minecraft.class_746;

public class RotationCalculator {

    public static class TargetRotation {
        public final Float yaw;
        public final Float pitch;

        public TargetRotation(Float yaw, Float pitch) {
            this.yaw = yaw;
            this.pitch = pitch;
        }
    }

    public static TargetRotation getRequiredRotation(class_2680 state, class_746 player) {
        class_2248 block = state.method_26204();

        // 1. Crafter Block (Minecraft 1.21) using Properties.ORIENTATION
        if (state.method_28498(class_2741.field_23333)) {
            class_5000 orientation = state.method_11654(class_2741.field_23333);
            class_2350 facing = orientation.method_26426();
            class_2350 rotation = orientation.method_26428();
            
            if (facing.method_10166() == class_2350.class_2351.field_11052) {
                // Vertical crafter: output facing determines pitch, rotation determines yaw.
                // If facing is UP, we click the top face of the block below, meaning we look DOWN (pitch = 90.0f).
                // If facing is DOWN, we click the bottom face of the block above, meaning we look UP (pitch = -90.0f).
                float pitch = facing == class_2350.field_11036 ? 90.0f : -90.0f;
                // player horizontal facing must be opposite of rotation
                TargetRotation yawRot = getRotationForLookDirection(rotation.method_10153(), false);
                return new TargetRotation(yawRot.yaw, pitch);
            } else {
                // Horizontal crafter: to place it facing the target direction, we must look at the opposite direction.
                // (since placed crafter faces the player).
                return getRotationForLookDirection(facing.method_10153(), true);
            }
        }

        // 2. Blocks with AXIS property (Logs, Wood, Pillars, Basalt, Nether Portal, Nether Wart Block/etc.)
        if (state.method_28498(class_2741.field_12496)) {
            class_2350.class_2351 axis = state.method_11654(class_2741.field_12496);
            if (axis == class_2350.class_2351.field_11052) {
                return new TargetRotation(null, 90.0f); // Look DOWN to place Y-axis blocks
            } else if (axis == class_2350.class_2351.field_11048) {
                if (player != null) {
                    float yaw = class_3532.method_15393(player.method_36454());
                    float targetYaw = (yaw < 0) ? -90.0f : 90.0f;
                    return new TargetRotation(targetYaw, null);
                } else {
                    return new TargetRotation(90.0f, null);
                }
            } else if (axis == class_2350.class_2351.field_11051) {
                if (player != null) {
                    float yaw = class_3532.method_15393(player.method_36454());
                    float targetYaw = (Math.abs(yaw) > 90.0f) ? 180.0f : 0.0f;
                    return new TargetRotation(targetYaw, null);
                } else {
                    return new TargetRotation(0.0f, null);
                }
            }
        }

        // 3. Blocks with HORIZONTAL_FACING property
        if (state.method_28498(class_2741.field_12481)) {
            class_2350 facing = state.method_11654(class_2741.field_12481);
            if (block instanceof class_2510 || block instanceof class_2533 || block instanceof class_2349 || 
                block instanceof class_2199 || block instanceof class_2323 || block instanceof class_2377) {
                return getRotationForLookDirection(facing, false);
            } else {
                return getRotationForLookDirection(facing.method_10153(), false);
            }
        }

        // 4. Blocks with FACING property (Piston, Dispenser, Dropper, Observer, etc.)
        if (state.method_28498(class_2741.field_12525)) {
            class_2350 facing = state.method_11654(class_2741.field_12525);
            if (block instanceof class_2426) {
                return getRotationForLookDirection(facing, true);
            } else if (block instanceof class_2377) {
                if (facing != class_2350.field_11033) {
                    return getRotationForLookDirection(facing, false);
                }
            } else {
                return getRotationForLookDirection(facing.method_10153(), true);
            }
        }

        return null;
    }

    private static TargetRotation getRotationForLookDirection(class_2350 dir, boolean is6Directional) {
        switch (dir) {
            case field_11036: return new TargetRotation(null, -90.0f); // Look UP -> pitch -90
            case field_11033: return new TargetRotation(null, 90.0f); // Look DOWN -> pitch 90
            case field_11035: return new TargetRotation(0.0f, is6Directional ? 0.0f : null); // Look SOUTH -> yaw 0
            case field_11039: return new TargetRotation(90.0f, is6Directional ? 0.0f : null); // Look WEST -> yaw 90
            case field_11043: return new TargetRotation(180.0f, is6Directional ? 0.0f : null); // Look NORTH -> yaw 180
            case field_11034: return new TargetRotation(-90.0f, is6Directional ? 0.0f : null); // Look EAST -> yaw -90
        }
        return null;
    }

    public static boolean isAlreadyCorrectRotation(class_746 player, TargetRotation rot) {
        if (rot == null) return true;

        if (rot.yaw != null) {
            class_2350 targetDir = getDirectionFromYaw(rot.yaw);
            if (targetDir != null && player.method_5735() != targetDir) {
                return false;
            }
        }

        if (rot.pitch != null) {
            float currentPitch = player.method_36455();
            if (rot.pitch == -90.0f) { // UP
                if (currentPitch > -45.0f) return false;
            } else if (rot.pitch == 90.0f) { // DOWN
                if (currentPitch < 45.0f) return false;
            } else {
                if (currentPitch < -45.0f || currentPitch > 45.0f) return false;
            }
        }

        return true;
    }

    private static class_2350 getDirectionFromYaw(float yaw) {
        float normalizedYaw = class_3532.method_15393(yaw);
        if (normalizedYaw >= -45.0f && normalizedYaw < 45.0f) {
            return class_2350.field_11035;
        } else if (normalizedYaw >= 45.0f && normalizedYaw < 135.0f) {
            return class_2350.field_11039;
        } else if (normalizedYaw >= -135.0f && normalizedYaw < -45.0f) {
            return class_2350.field_11034;
        } else {
            return class_2350.field_11043;
        }
    }

    public static float alignYawToSensitivity(float targetYaw, float currentYaw, class_310 client) {
        double sensitivity = client.field_1690.method_42495().method_41753();
        float f = (float) (sensitivity * 0.6F + 0.2F);
        float g = f * f * f * 8.0F;
        float gcd = g * 0.15F;

        float yawDiff = targetYaw - currentYaw;
        yawDiff = class_3532.method_15393(yawDiff);
        int steps = Math.round(yawDiff / gcd);
        return currentYaw + steps * gcd;
    }

    public static float alignPitchToSensitivity(float targetPitch, float currentPitch, class_310 client) {
        double sensitivity = client.field_1690.method_42495().method_41753();
        float f = (float) (sensitivity * 0.6F + 0.2F);
        float g = f * f * f * 8.0F;
        float gcd = g * 0.15F;

        float pitchDiff = targetPitch - currentPitch;
        int steps = Math.round(pitchDiff / gcd);
        float alignedPitch = currentPitch + steps * gcd;
        return class_3532.method_15363(alignedPitch, -90.0f, 90.0f);
    }
}
