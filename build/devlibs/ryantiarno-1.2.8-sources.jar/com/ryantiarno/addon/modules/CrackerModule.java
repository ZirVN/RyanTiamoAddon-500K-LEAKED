package com.ryantiarno.addon.modules;

import com.ryantiarno.addon.RyanAddon;
import meteordevelopment.meteorclient.systems.modules.Module;

public class CrackerModule extends Module {
    public CrackerModule() {
        super(RyanAddon.CATEGORY, "cracker-detector", "Cracker detector module.");
    }
}

