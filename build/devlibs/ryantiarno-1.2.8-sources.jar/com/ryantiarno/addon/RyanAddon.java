package com.ryantiarno.addon;

import com.ryantiarno.addon.config.ModConfig;
import com.ryantiarno.addon.modules.AutoDirection;
import com.ryantiarno.addon.modules.AutoPlace;
import com.ryantiarno.addon.modules.AutoSell;
import com.ryantiarno.addon.modules.CrackerModule;
import com.ryantiarno.addon.modules.CrafterSetup;
import com.ryantiarno.addon.modules.DiscordRPC;
import com.ryantiarno.addon.modules.FakeSneak;
import com.ryantiarno.addon.modules.GuiClose;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.item.Items;

public class RyanAddon extends MeteorAddon {
    public static final Category CATEGORY = new Category("Ryan x Tiamo", Items.NETHERITE_SWORD.getDefaultStack());
    private static boolean initialized = false;

    public static void registerModules() {
        if (!initialized) {
            initialized = true;
            System.out.println("[RyanAddon] Registering modules...");
            Modules.get().add(new AutoDirection());
            Modules.get().add(new AutoPlace());
            Modules.get().add(new AutoSell());
            Modules.get().add(new CrafterSetup());
            Modules.get().add(new CrackerModule());
            Modules.get().add(new FakeSneak());
            Modules.get().add(new GuiClose());
            DiscordRPC.IlllIIIl();
        }
    }

    @Override
    public void onInitialize() {
        System.out.println("[RyanAddon] Initializing Ryan x Tiamo Addon (Clean/Cracked)...");
        ModConfig.load();
        registerModules();
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.ryantiarno.addon";
    }
}

