package com.ryantiarno.addon.mixins;

import com.ryantiarno.addon.modules.AutoSell;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatHud.class)
public class ChatHudMixin {
    @Inject(
        method = "addMessage(Lnet/minecraft/text/Text;)V",
        at = @At("HEAD")
    )
    private void onAddMessage(Text message, CallbackInfo ci) {
        if (message != null) {
            try {
                AutoSell.onChatMessage(message.getString());
            } catch (Exception ignored) {}
        }
    }
}

